import { useState, useEffect } from "react"
import { supabase } from "./supabase"
import Inventory from "./inventory-system"

export default function App() {
  const [session, setSession] = useState(null)
  const [loading, setLoading] = useState(true)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [isLogging, setIsLogging] = useState(false)

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session)
      setLoading(false)
    })
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session)
    })
    return () => subscription.unsubscribe()
  }, [])

  async function handleLogin(e) {
    e.preventDefault()
    setIsLogging(true)
    setError("")
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    if (error) setError("ایمیل یا پسورد اشتباه است")
    setIsLogging(false)
  }

  async function handleLogout() {
    await supabase.auth.signOut()
  }

  if (loading) return (
    <div style={{ display:"flex", alignItems:"center", justifyContent:"center", minHeight:"100vh", background:"#0e1220" }}>
      <div style={{ color:"#6366f1", fontSize:18 }}>در حال بارگذاری...</div>
    </div>
  )

  if (!session) return (
    <div style={{ display:"flex", alignItems:"center", justifyContent:"center", minHeight:"100vh", background:"#0e1220", fontFamily:"'Inter','Tahoma',sans-serif" }}>
      <div style={{ background:"#161b2c", border:"1px solid #252f4a", borderRadius:20, padding:"40px 36px", width:"100%", maxWidth:400 }}>
        
        {/* Logo */}
        <div style={{ textAlign:"center", marginBottom:32 }}>
          <div style={{ fontSize:48, color:"#6366f1", marginBottom:8 }}>▦</div>
          <div style={{ color:"#f0f4ff", fontSize:24, fontWeight:800, letterSpacing:"-0.5px" }}>StockTrack</div>
          <div style={{ color:"#8892b0", fontSize:13, marginTop:4 }}>سیستم کنترل انبار</div>
        </div>

        {/* Form */}
        <form onSubmit={handleLogin}>
          <div style={{ marginBottom:16 }}>
            <label style={{ display:"block", color:"#8892b0", fontSize:12, marginBottom:6 }}>ایمیل</label>
            <input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="example@email.com"
              required
              style={{ width:"100%", background:"#0e1220", border:"1px solid #252f4a", borderRadius:10, padding:"12px 14px", color:"#f0f4ff", fontSize:14, outline:"none", boxSizing:"border-box" }}
            />
          </div>
          <div style={{ marginBottom:24 }}>
            <label style={{ display:"block", color:"#8892b0", fontSize:12, marginBottom:6 }}>پسورد</label>
            <input
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="••••••••"
              required
              style={{ width:"100%", background:"#0e1220", border:"1px solid #252f4a", borderRadius:10, padding:"12px 14px", color:"#f0f4ff", fontSize:14, outline:"none", boxSizing:"border-box" }}
            />
          </div>

          {error && (
            <div style={{ background:"rgba(248,113,113,.1)", border:"1px solid rgba(248,113,113,.3)", borderRadius:8, padding:"10px 14px", color:"#f87171", fontSize:13, marginBottom:16, textAlign:"center" }}>
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={isLogging}
            style={{ width:"100%", background:"linear-gradient(135deg,#6366f1,#8b5cf6)", border:"none", borderRadius:10, color:"#fff", padding:"13px", cursor:"pointer", fontSize:15, fontWeight:700, fontFamily:"inherit", opacity: isLogging ? 0.7 : 1 }}
          >
            {isLogging ? "در حال ورود..." : "ورود"}
          </button>
        </form>

        <div style={{ marginTop:20, padding:"14px", background:"rgba(99,102,241,.08)", borderRadius:10, border:"1px solid rgba(99,102,241,.2)" }}>
          <div style={{ color:"#8892b0", fontSize:11, textAlign:"center", lineHeight:1.7 }}>
            برای اضافه کردن کاربر جدید به<br/>
            <span style={{ color:"#a5b4fc" }}>Supabase → Authentication → Users</span><br/>
            برو و کاربر اضافه کن
          </div>
        </div>
      </div>
    </div>
  )

  return (
    <div>
      {/* Logout bar */}
      <div style={{ position:"fixed", top:0, left:0, right:0, height:40, background:"#090d18", borderBottom:"1px solid #1a2035", display:"flex", alignItems:"center", justifyContent:"space-between", padding:"0 20px", zIndex:500, fontSize:12 }}>
        <span style={{ color:"#8892b0" }}>👤 {session.user.email}</span>
        <button onClick={handleLogout} style={{ background:"rgba(248,113,113,.1)", border:"1px solid rgba(248,113,113,.3)", borderRadius:6, color:"#f87171", padding:"4px 12px", cursor:"pointer", fontSize:11, fontFamily:"inherit" }}>
          خروج
        </button>
      </div>
      {/* Inventory app with top padding for the bar */}
      <div style={{ paddingTop:40 }}>
        <Inventory />
      </div>
    </div>
  )
}
